from django.apps import AppConfig


class Bb4KappBackendConfig(AppConfig):
    name = 'bb4kApp_backend'
